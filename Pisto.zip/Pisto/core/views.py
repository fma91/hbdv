from django.shortcuts import render, HttpResponse


# Create your views here.
def home(request):
    return render(request,'core/home.html')
    

def topics(request):
    return render(request, 'core/topics.html')


def MC(request):
    return HttpResponse('<h1>Test1</h1>')

def MCF(request):
    return HttpResponse('<h1>Test2</h1>')




def about(request):
    return render(request,'core/about.html')



def contact(request):
    return render(request, 'core/contact.html')